package com.ilya.careducation.secondfragment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.ilya.careducation.R;
import com.ilya.careducation.electro.KlimatActivity;
import com.ilya.careducation.electro.MagnitActivity;
import com.ilya.careducation.electro.PredActivity;
import com.ilya.careducation.electro.PriborActivity;
import com.ilya.careducation.electro.SvetActivity;
import com.ilya.careducation.trans.AvtomatActivity;
import com.ilya.careducation.trans.MehActivity;
import com.ilya.careducation.trans.RobotActivity;

import java.util.Objects;

public class TransActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trans);
        //трансмиссия
        Toolbar toolbar = findViewById(R.id.toolkrish);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        //создание кнопки на appbar

        String[] title = {"Автоматическая коробка передач", "Механическая коробка передач", "Роботизированная коробка передач"};
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, title);

        ListView listView =(ListView) findViewById(R.id.listtrans);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            switch(position){
                case(0):{
                    startActivity(new Intent(this, AvtomatActivity.class));
                    //вызов активности автоматической коробки передач
                    break;
                }
                case(1):{
                    startActivity(new Intent(this, MehActivity.class));
                    //вызов активности механической коробки передач
                    break;
                }
                case(2):{
                    startActivity(new Intent(this, RobotActivity.class));
                    //вызов активности роботизированной коробки передач
                    break;
                }
            }
        });
    }
}