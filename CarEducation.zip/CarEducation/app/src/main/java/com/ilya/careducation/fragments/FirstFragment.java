package com.ilya.careducation.fragments;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.fragment.app.Fragment;

import com.ilya.careducation.R;
import com.ilya.careducation.firstfragment.AkkumActivity;
import com.ilya.careducation.firstfragment.BochkiActivity;
import com.ilya.careducation.firstfragment.FiltrActivity;
import com.ilya.careducation.firstfragment.KrishActivity;
import com.ilya.careducation.firstfragment.VozduhActivity;

public class FirstFragment extends Fragment implements View.OnClickListener {
    public FirstFragment() {
        // Required empty public constructor
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.firstfragment, container, false);

        //этот фрагмент отвечает за то, что расположено в подкапотном пространстве:
        //сам двигатель, воздушный фильтр, дроссельную заслонку, различные технические жидкости,
        //и аккумулятор


        ImageButton Krish = v.findViewById(R.id.krish);
        Button Krish1 = v.findViewById(R.id.krish1);
        ImageButton Vozduh = v.findViewById(R.id.vozduh);
        ImageButton Akkum = v.findViewById(R.id.akkum);
        ImageButton Filtr = v.findViewById(R.id.filtr);
        ImageButton Bochki = v.findViewById(R.id.bochki);
        Button Bochki1 = v.findViewById(R.id.bochki1);
        Button Bochki2 = v.findViewById(R.id.bochki2);
        Button Bochki3 = v.findViewById(R.id.bochki3);
        Button Bochki4 = v.findViewById(R.id.bochki4);


        Krish.setOnClickListener(this);
        Krish1.setOnClickListener(this);
        Vozduh.setOnClickListener(this);
        Akkum.setOnClickListener(this);
        Filtr.setOnClickListener(this);
        Bochki.setOnClickListener(this);
        Bochki1.setOnClickListener(this);
        Bochki2.setOnClickListener(this);
        Bochki3.setOnClickListener(this);
        Bochki4.setOnClickListener(this);
        return v;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.krish: {
                startActivity(new Intent(getActivity(), KrishActivity.class));
                //запуск активности, отвечающей за двигатель
                break;
            }
            case R.id.krish1:
            case R.id.vozduh: {
                startActivity(new Intent(getActivity(), VozduhActivity.class));
                //запуск активности, отвечающей за дроссельную заслонку
                break;
            }
            case R.id.akkum: {
                startActivity(new Intent(getActivity(), AkkumActivity.class));
                //запуск активности, отвечающей за аккумулятор
                break;
            }
            case R.id.bochki:
            case R.id.bochki1:
            case R.id.bochki2:
            case R.id.bochki3:
            case R.id.bochki4: {
                startActivity(new Intent(getActivity(), BochkiActivity.class));
                //запуск активности, отвечающей за технические жидкости
                break;
            }
            case R.id.filtr: {
                startActivity(new Intent(getActivity(), FiltrActivity.class));
                //запуск активности, отвечающей за воздушный фильтр
                break;
            }

        }
    }
}

