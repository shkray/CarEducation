package com.ilya.careducation.fragments;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.ilya.careducation.R;
import com.ilya.careducation.thirdfragment.ElecroActivity;
import com.ilya.careducation.thirdfragment.TopActivity;
import com.ilya.careducation.thirdfragment.TormActivity;


public class ThirdFragment extends Fragment {
    ListView listView;
    String[] Title = {"Электричество", "Топливная система", "Тормозная система"};
    int[] images = {R.drawable.flash, R.drawable.car};

    public ThirdFragment() {
        // Required empty public constructor
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.thirdfragment, container, false);

        //эта активность отвечает за электричество, тормозную и топливную системы.

        listView =(ListView) v.findViewById(R.id.ListView);
        ArrayAdapter adapter = new ArrayAdapter(getActivity(), android.R.layout.simple_list_item_1, Title);
        listView.setAdapter(adapter);
        //создание listview, и присваивание адаптера


        listView.setOnItemClickListener((parent, view, position, id) -> {
            switch(position){
                case(0):{
                    startActivity(new Intent(getActivity(), ElecroActivity.class));
                    //запуск активности, отвечающей за электросеть
                    break;
                }
                case(1):{
                    startActivity(new Intent(getActivity(), TopActivity.class));
                    //запуск активности, отвечающей за топливную систему
                    break;
                }
                case(2):{
                    startActivity(new Intent(getActivity(), TormActivity.class));
                    //запуск активности, отвечающей за тормозную систему
                    break;
                }
            }
        });
        return v;


    }
}
