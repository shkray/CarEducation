package com.ilya.careducation;

import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.Objects;


public class MainActivity extends AppCompatActivity {

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolkrish);
        setSupportActionBar(toolbar);
        ViewPager2 viewpager = findViewById(R.id.ViewPager);
        viewpager.setAdapter(new PagerAdapter(this));

        TabLayout tablayout = findViewById(R.id.appbar1);
        new TabLayoutMediator(tablayout, viewpager, (tab, position) -> {
            switch (position) {
                case 0: {
                    tab.setText("Двигатель");
                    break;
                }
                case 1: {
                    tab.setText("Ходовка");
                    break;
                }
                case 2: {
                    tab.setText("Мелочи");
                    break;
                }
            }
        }
        ).attach();

    }
}