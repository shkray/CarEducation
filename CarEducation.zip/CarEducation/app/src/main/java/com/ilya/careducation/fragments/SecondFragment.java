package com.ilya.careducation.fragments;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;

import com.ilya.careducation.R;
import com.ilya.careducation.firstfragment.KrishActivity;
import com.ilya.careducation.secondfragment.BarActivity;
import com.ilya.careducation.secondfragment.KolesoActivity;
import com.ilya.careducation.secondfragment.TransActivity;

public class SecondFragment extends Fragment implements View.OnClickListener {
    public SecondFragment() {
        // Required empty public constructor
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.secondfragment, container, false);


        //этот фрагмент отвечает за ходовую часть автомобиля, рулевое управление и трансмиссию.



        Button koleso1 = v.findViewById(R.id.koleso1);
        koleso1.setOnClickListener(this);
        Button koleso2 = v.findViewById(R.id.koleso2);
        koleso2.setOnClickListener(this);
        Button koleso3 = v.findViewById(R.id.koleso3);
        koleso3.setOnClickListener(this);
        Button koleso10 = v.findViewById(R.id.koleso10);
        koleso10.setOnClickListener(this);
        Button koleso4 = v.findViewById(R.id.koleso4);
        koleso4.setOnClickListener(this);
        Button koleso5 = v.findViewById(R.id.koleso5);
        koleso5.setOnClickListener(this);
        Button koleso6 = v.findViewById(R.id.koleso6);
        koleso6.setOnClickListener(this);
        Button koleso7 = v.findViewById(R.id.koleso7);
        koleso7.setOnClickListener(this);
        Button koleso8 = v.findViewById(R.id.koleso8);
        koleso8.setOnClickListener(this);
        Button koleso9 = v.findViewById(R.id.koleso9);
        koleso9.setOnClickListener(this);
        Button koleso11 = v.findViewById(R.id.koleso11);
        koleso11.setOnClickListener(this);
        Button koleso12 = v.findViewById(R.id.koleso12);
        koleso12.setOnClickListener(this);
        Button koleso13 = v.findViewById(R.id.koleso13);
        koleso13.setOnClickListener(this);
        Button koleso14 = v.findViewById(R.id.koleso14);
        koleso14.setOnClickListener(this);
        Button koleso15 = v.findViewById(R.id.koleso15);
        koleso15.setOnClickListener(this);
        Button koleso16 = v.findViewById(R.id.koleso16);
        koleso16.setOnClickListener(this);

        Button trans1 = v.findViewById(R.id.trans1);
        trans1.setOnClickListener(this);
        Button trans2 = v.findViewById(R.id.trans2);
        trans2.setOnClickListener(this);
        Button trans3 = v.findViewById(R.id.trans3);
        trans3.setOnClickListener(this);
        Button trans4 = v.findViewById(R.id.trans4);
        trans4.setOnClickListener(this);

        Button bar1 = v.findViewById(R.id.bar1);
        bar1.setOnClickListener(this);
        Button bar2 = v.findViewById(R.id.bar2);
        bar2.setOnClickListener(this);

        return v;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.koleso1:
            case R.id.koleso2:
            case R.id.koleso3:
            case R.id.koleso4:
            case R.id.koleso5:
            case R.id.koleso6:
            case R.id.koleso7:
            case R.id.koleso8:
            case R.id.koleso9:
            case R.id.koleso10:
            case R.id.koleso11:
            case R.id.koleso12:
            case R.id.koleso13:
            case R.id.koleso14:
            case R.id.koleso15:
            case R.id.koleso16:{
                startActivity(new Intent(getActivity(), KolesoActivity.class));
                //запуск активности, отвечающей за подвеску
                break;
            }
            case R.id.trans1:
            case R.id.trans2:
            case R.id.trans3:
            case R.id.trans4:{
                startActivity(new Intent(getActivity(), TransActivity.class));
                //запуск активности, отвечающей за трансмиссию
                break;
            }
            case R.id.bar1:
            case R.id.bar2:{
                startActivity(new Intent(getActivity(), BarActivity.class));
                //запуск активности, отвечающей за рулевое управление
                break;
            }
        }
    }
}
