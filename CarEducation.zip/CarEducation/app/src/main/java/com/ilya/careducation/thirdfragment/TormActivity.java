package com.ilya.careducation.thirdfragment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;

import com.ilya.careducation.R;

import java.util.Objects;

public class TormActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //тормозная система
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_torm);
        Toolbar toolbar = findViewById(R.id.toolkrish);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
    }
}