package com.ilya.careducation.thirdfragment;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.ilya.careducation.R;
import com.ilya.careducation.electro.KlimatActivity;
import com.ilya.careducation.electro.MagnitActivity;
import com.ilya.careducation.electro.PredActivity;
import com.ilya.careducation.electro.PriborActivity;
import com.ilya.careducation.electro.SvetActivity;

import java.util.Objects;


public class ElecroActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elecro);
        Toolbar toolbar = findViewById(R.id.toolkrish);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        //электрическая сеть


        String[] title = {"Магнитола", "Климат контроль", "Предохранители", "Лампы освещения", "Приборная панель"};
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, title);

        ListView listView =(ListView) findViewById(R.id.listelectro);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            switch(position){
                case(0):{
                    startActivity(new Intent(this, MagnitActivity.class));
                    //магнитола
                    break;
                }
                case(1):{
                    startActivity(new Intent(this, KlimatActivity.class));
                    //климат контроль
                    break;
                }
                case(2):{
                    startActivity(new Intent(this, PredActivity.class));
                    //предохранители
                    break;
                }
                case(3):{
                    startActivity(new Intent(this, SvetActivity.class));
                    //свет
                    break;
                }
                case(4):{
                    startActivity(new Intent(this, PriborActivity.class));
                    //приборная панель
                    break;
                }
            }
        });
    }
}